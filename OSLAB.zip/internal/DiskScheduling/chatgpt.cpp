#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include<climits>

using namespace std;

// Function to find the index of the nearest track
int findNearestTrack(vector<int>& tracks, int current) {
    int minDistance = INT_MAX;
    int index = -1;

    for (int i = 0; i < tracks.size(); ++i) {
        int distance = abs(tracks[i] - current);
        
        if (distance < minDistance) {
            minDistance = distance;
            index = i;
        }
    }

    return index;
}

// Function to perform SSTF scheduling
void sstf(vector<int>& requestQueue, int initialPosition) {

    int totalSeekOperations = 0;
    int currentHeadPosition = initialPosition;

    cout << "SSTF Schedule: ";
    int count=0;
    
    while (!requestQueue.empty()) {
    
        int nearestTrackIndex = findNearestTrack(requestQueue, currentHeadPosition);
        
        int nextTrack = requestQueue[nearestTrackIndex];

        cout << nextTrack << " ";

        // Update total seek operations
        totalSeekOperations += abs(nextTrack - currentHeadPosition);

        // Move the head to the next track
        currentHeadPosition = nextTrack;

        // Remove the processed track from the request queue
        requestQueue.erase(requestQueue.begin() + nearestTrackIndex);
        count++;
    }

    cout << "\nTotal Seek Operations: " << totalSeekOperations << endl;
    cout<<count;
}

int main() {
    int n;
    cout << "Enter the number of tracks in the request queue: ";
    cin >> n;

    vector<int> requestQueue(n);

    cout << "Enter the track numbers in the request queue:\n";
    for (int i = 0; i < n; ++i) {
        cin >> requestQueue[i];
    }

    int initialPosition;
    cout << "Enter the initial head position: ";
    cin >> initialPosition;

    sstf(requestQueue, initialPosition);

    return 0;
}

