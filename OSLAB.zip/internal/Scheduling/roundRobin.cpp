#include<bits/stdc++.h>
using namespace std;
struct process
{
	string pID;
	int at,bt,ct,tat,wt;
};
void rr(process *p,int n,int tq)
{
	int burst[n];
	for(int i=0;i<n;i++)
	{
		burst[i]=p[i].bt;
	}
	int time=0;
	int count=0;
	while(count<n)
	{
		int selected=-1;
		int lowArrivalTime=INT_MAX;
		for(int i=0;i<n;i++)
		{
			if( p[i].at<=time and  p[i].at<lowArrivalTime and p[i].bt>0)
			{
				lowArrivalTime=p[i].at;
				selected=i;
			}
		}
		if(selected==-1)
		{
			time++;
		}
		else
		{
			if(p[selected].bt>=tq)
			{
				p[selected].bt=p[selected].bt-tq;
				time=time+tq;
			}
			else
			{
				time=time+p[selected].bt;
				p[selected].bt=0;
				
			}
			if(p[selected].bt==0)
			{
				p[selected].ct=time;
				p[selected].tat=p[selected].ct-p[selected].at;
				p[selected].wt=p[selected].tat-burst[selected];
				count++;
			}
			
		}
	}
}
void display(process *p,int n)
{
	cout<<"Id "<<"at" <<" bt" <<" CT"<<" "<<"TAT"<<" "<<"WT"<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<p[i].pID<<"  "<<p[i].at<<" "<<p[i].bt<<"  "<<p[i].ct<<" "<<p[i].tat<<"   "<<p[i].wt<<" "<<endl;
    }
}
int main()
{
	int n,tq;
	cout<<"enter number of processes ";
	cin>>n;
	cout<<"enter time quantum ";
	cin>>tq;
	process p[n];
	cout<<"enter the process Id,arrival time,burst time"<<endl;
	for(int i=0;i<n;i++)
	{
		cin>>p[i].pID>>p[i].at>>p[i].bt;
	}
	rr(p,n,tq);
	display(p,n);
}
